#pragma once
using std::string;

enum DegreeProgram { SECURITY, NETWORK, SOFTWARE };
static const string degreeProgramType[] = { "SECURITY", "NETWORK", "SOFTWARE" };
